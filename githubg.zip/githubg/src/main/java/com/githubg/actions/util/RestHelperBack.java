package com.githubg.actions.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.client.RestTemplate;

public class RestHelperBack {

	private RestTemplate restTemplate;
	
	public RestHelperBack() {
		restTemplate = new RestTemplate();
	}

	@Autowired
	RestHelperBack(RestTemplateBuilder builder) {
		restTemplate = builder.build();
	}
	
	public RestTemplate getRestTemplate() {
		return restTemplate;
	}

}