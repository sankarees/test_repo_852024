package com.githubg.actions.exceptions;

public class DataNotFound extends Exception {
	public DataNotFound(String message) {
		super(message);
	}
}