package com.githubg.actions;
/*
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
*/
//@SpringBootTest
class GithubgApplicationTests {

//	@Test
	void contextLoads() {
	}

}
